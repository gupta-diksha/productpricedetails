package com.cg.productmgmt.service;

import com.cg.productmgmt.dao.IProductDAO;
import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.util.CollectionUtil;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class ProductService implements IProductService {
	
	IProductDAO productDao = new ProductDAO();
	@Override
	public int updateProducts(String Category, int hike)throws ProductException
	{
		int updatedamount=productDao.updateProducts(Category, hike);
		return updatedamount;
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException
	{
		
		
		return CollectionUtil.getSalesDetails();
	}
	public boolean validateHikeRate(int hike)throws ProductException//checking Hike rate
	{
		if(hike>0)
			return true;
		else
			return false;
	}
	public boolean checkCategory(String category)throws ProductException//checkingCategory
	{ 
		
		Map<String,String> productList = CollectionUtil.getProductCategory();
		Set<Map.Entry<String,String>> dirSet = productList.entrySet();
		Iterator<Map.Entry<String,String>> itSet = dirSet.iterator();
		boolean flag = false;
		while(itSet.hasNext())
		{
			
			Map.Entry entry1 = itSet.next();
			if(category.equals(entry1.getValue()))
			{
				flag=true;
			}
		}
			return flag;
		}	
			
	

}
