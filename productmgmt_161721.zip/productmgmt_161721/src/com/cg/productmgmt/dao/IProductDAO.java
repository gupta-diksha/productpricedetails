package com.cg.productmgmt.dao;

import com.cg.productmgmt.exception.ProductException;
import java.util.Map;

public interface IProductDAO {

	//interface of ProductDAO
	public int updateProducts(String Category,int hike)throws ProductException;
	public Map<String,Integer> getProductDetails() throws ProductException;
}
