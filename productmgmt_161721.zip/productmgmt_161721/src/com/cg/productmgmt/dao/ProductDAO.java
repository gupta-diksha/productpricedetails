package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.util.CollectionUtil;

public class ProductDAO implements IProductDAO
{
	
	@Override
	public int updateProducts(String Category, int hike)throws ProductException {
		
		Map<String,String> productList = CollectionUtil.getProductCategory();
		Map<String,Integer> salesList = CollectionUtil.getSalesDetails();
		Set<Map.Entry<String,String>> productSet = productList.entrySet();
		Set<Map.Entry<String,Integer>> salesSet = salesList.entrySet();
		Iterator<Map.Entry<String,String>> itSet1 = productSet.iterator();
		Iterator<Map.Entry<String,Integer>> itSet2 = salesSet.iterator();
		boolean flag = false;
		String key=null;
		int finalamount=0;
		int tempamount=0;
		while(itSet1.hasNext())
		{
			Map.Entry entry1 = itSet1.next();
			if(Category.equals(entry1.getValue()))//checking for category mapping
			{
				key=(String)entry1.getKey();
				while(itSet2.hasNext())
				{
					Map.Entry entry2 = itSet2.next();
					if(key.equals(entry2.getKey()))//checking for key mapping and updating that amount
					{
						tempamount=(Integer)entry2.getValue();
						finalamount= tempamount+((hike/100)*tempamount);
						
						entry2.setValue(finalamount);
					}
				}
			}
		}
		
		return finalamount;
	}
	@Override
	public Map<String,Integer> getProductDetails() throws ProductException {
		
		return CollectionUtil.getSalesDetails();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
