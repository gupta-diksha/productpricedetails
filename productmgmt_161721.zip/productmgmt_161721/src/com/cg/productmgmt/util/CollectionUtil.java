package com.cg.productmgmt.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;



public class CollectionUtil {
	
	static Map<String,String> productDetails;
	static Map<String,Integer> salesDetails;
	static
	{
		productDetails = new HashMap<>();
		productDetails.put("lux", "soap");
		productDetails.put("colgate", "paste");
		productDetails.put("pears", "soap");
		productDetails.put("sony", "electronics");
		productDetails.put("samsung", "electronics");
		productDetails.put("facepack", "cosmetics");
		productDetails.put("facecream", "cosmetics");
		
		salesDetails = new HashMap<>();
		salesDetails.put("lux", 100);
		salesDetails.put("colgate", 50);
		salesDetails.put("pears", 70);
		salesDetails.put("sony", 10000);
		salesDetails.put("samsung", 23000);
		salesDetails.put("facepack", 100);
		salesDetails.put("facecream", 60);
		
		
	}
	
	public static Map<String,String> getProductCategory()
	{
		return productDetails;
	}
	 
	public static Map<String,Integer> getSalesDetails()
	{
		return salesDetails;
	}

}
