package com.cg.productmgmt.junit;

import junit.framework.Assert;

import org.junit.BeforeClass;


import org.junit.Test;

import com.cg.productmgmt.dao.IProductDAO;
import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;



public class ProductDAOTest {
	
	static IProductDAO productDao = null;
	static IProductService productSer = null;
	@BeforeClass

	public static void setUp()
	{
		productDao= new ProductDAO();
	}
	
	@Test
	 public static void updateProductTest()throws ProductException
	 {
		int result=productDao.updateProducts("lux", 2);
		Assert.assertEquals(102,result);
	 }
	@Test
	 public static void updateProductTestNegative()throws ProductException
	 {
		int result=productDao.updateProducts("lux", -2);
		Assert.assertEquals(false,result);
	 }
	@Test
	 public static void validateHikeRateTest()throws ProductException
	 {
		
		Assert.assertEquals(false,productSer.validateHikeRate(-2));
	 }
	

}
