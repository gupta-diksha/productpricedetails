package com.cg.productmgmt.ui;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;
import com.cg.productmgmt.util.CollectionUtil;

public class Client
{
	static Scanner sc = null;
	static IProductService productSer = null;
	public static void main(String[] args) throws ProductException
	{
		
		sc = new Scanner(System.in);
		int choice =0;
		while(true)
		{
			System.out.println("*******Menu*******");
			System.out.println("1-Update Product Price");
			System.out.println("2-Exit");
			System.out.println("Enter your choice:");
			choice= sc.nextInt();
			
			switch(choice)
			{
				case 1: updateProductPrice();
						break;
				default: System.exit(0);		
			}
		}

	}

	public static void updateProductPrice() throws ProductException
	{ 
		sc = new Scanner(System.in);
		productSer= new ProductService();
		System.out.println("Enter the Product Category :");
		String category = sc.next();
		if(productSer.checkCategory(category))
		{	
			System.out.println("Enter the Hike Rate :");
			int hikeRate = sc.nextInt();
			if(productSer.validateHikeRate(hikeRate))
			{
				int updatedamount=productSer.updateProducts(category, hikeRate);
				System.out.println("The update price list:");
				Map<String,Integer> salesList = CollectionUtil.getSalesDetails();
				Set<Map.Entry<String,Integer>> dirSet = salesList.entrySet();
				Iterator<Entry<String, Integer>> itSet = dirSet.iterator();
				while(itSet.hasNext())
				{
					Map.Entry entry1 = itSet.next();//printing sales details
					System.out.println("Product Name:"+entry1.getKey()+"\tPrice:"+entry1.getValue());
				}
				
				
			}
			else 
				throw new ProductException("Invalid Hike rate!! Enter Hike greater than 0!");
		}
		else
			throw new ProductException("Invalid Category entered!");
	}
	
	
	

}
